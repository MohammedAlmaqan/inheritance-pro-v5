package com.inheritance.pro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
